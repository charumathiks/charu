package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Book;
import com.cg.service.BookServiceImpl;
import com.cg.service.IBookService;
import com.cg.exception.BookException;

/**
 * Servlet implementation class BookController
 */
@WebServlet("/BookController")
public class BookController extends HttpServlet {
	private static final long serialVersionUID = 1L;
     IBookService bookService;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String opera = request.getParameter("action");
		PrintWriter out = response.getWriter();
		RequestDispatcher view = null;
   bookService = new BookServiceImpl();
   if (opera != null && "add".equals(opera)) {
		view = request.getRequestDispatcher("Book.html");
		view.forward(request, response);
	}
   Book b1 =new Book();
   if (opera != null && "Append Book".equals(opera)) {
   String BookName= request.getParameter("bookName");
   int BookId=Integer.parseInt(request.getParameter("bookId"));
   String BookAuthor=request.getParameter("bookAuthor");
   String BookPublishYear=request.getParameter("bookPublishYear");
   b1.setBookName(BookName);
   b1.setBookId(BookId);
   b1.setBookAuthor(BookAuthor);
   b1.setBookPublish(BookPublishYear);
   try {
		int records = bookService.InsertBook(b1);
		if (records != 0) {
			view = request.getRequestDispatcher("success.html");
			view.forward(request, response);
		} else {
			out.println("Inserting Book details failed");
			view = request.getRequestDispatcher("error.html");
			view.include(request, response);
		}
	} catch (BookException e) {
		out.println("Error while inserting book details");
		view = request.getRequestDispatcher("error.html");
		view.include(request, response);
	}}}
  
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
