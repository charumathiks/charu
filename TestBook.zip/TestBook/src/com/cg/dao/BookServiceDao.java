package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bean.Book;
import com.cg.exception.BookException;
import com.cg.service.BookServiceImpl;
import com.cg.service.IBookService;
import com.cg.util.BookDB;

public class BookServiceDao implements IBookDao{
IBookService bookService;
public BookServiceDao() {
	bookService = new BookServiceImpl();
}
Connection connection = null;
Statement statement = null;
ResultSet rsSet = null;
PreparedStatement preparedStatement = null;
	@Override
	public boolean isValidBookName(String str) throws BookException {

		return bookService.isValidBookName(str);
	}

	@Override
	public int InsertBook(Book book) throws BookException {
		connection= BookDB.obtainConnection();
		String sql = "INSERT INTO BOOK VALUES(?,?,?,?)";
		int recordInserted = 0;
			try {
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, book.getBookName());
				preparedStatement.setInt(2, book.getBookId());
				preparedStatement.setString(3, book.getBookAuthor());
				preparedStatement.setString(4, book.getBookPublishYear());

				recordInserted = preparedStatement.executeUpdate();
			} catch (SQLException e) {
				throw new BookException("Error while inserting values::"
						+ e.getMessage());
			}
		
		return bookService.InsertBook(book);
		
	}

	@Override
	public boolean isValidBookId(String str) throws BookException {
	return bookService.isValidBookId(str);
	}


}
