package com.cg.service;

import com.cg.bean.Book;
import com.cg.exception.BookException;

public class BookServiceImpl implements IBookService {
	IBookService bookService;
	public BookServiceImpl() {
		bookService=new BookServiceImpl();
	}
	@Override
	public boolean isValidBookName(String str) throws BookException {
		
		return bookService.isValidBookName(str); 
	}

	@Override
	public int InsertBook(Book book) throws BookException {
		 return bookService.InsertBook(book);
		
	}

	@Override
	public boolean isValidBookId(String str) throws BookException {
		return bookService.isValidBookId(str);
	}

	

}
