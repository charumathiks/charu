package com.cg.service;

import com.cg.bean.Book;
import com.cg.exception.BookException;

public interface IBookService {
public boolean isValidBookName(String str) throws BookException;
public int InsertBook(Book book) throws BookException;
public boolean isValidBookId(String str) throws BookException;
}
