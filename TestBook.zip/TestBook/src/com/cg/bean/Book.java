package com.cg.bean;

public class Book {
private int BookId;
private String BookName;
private String BookAuthor;
private String BookPublishYear;
public int getBookId() {
	return BookId;
}
public void setBookId(int bookId) {
	BookId = bookId;
}
public String getBookName() {
	return BookName;
}
public void setBookName(String bookName) {
	BookName = bookName;
}
public String getBookAuthor() {
	return BookAuthor;
}
public void setBookAuthor(String bookAuthor) {
	BookAuthor = bookAuthor;
}
public String getBookPublishYear() {
	return BookPublishYear;
}
public void setBookPublish(String bookPublishYear) {
	BookPublishYear = bookPublishYear;
}

}
