package com.java.bean;

public class Electricity {
	private String ConsumerName;
	private int consumerId;
	private float lastMonthReading;
	private float currentMonthReading;
	private float unitConsumed;
	private float billAmount;
	public String getConsumerName() {
		return ConsumerName;
	}
	public void setConsumerName(String consumerName) {
		ConsumerName = consumerName;
	}
	public int getConsumerId() {
		return consumerId;
	}
	public void setConsumerId(int consumerId) {
		this.consumerId = consumerId;
	}
	public float getLastMonthReading() {
		return lastMonthReading;
	}
	public void setLastMonthReading(float lastMonthReading) {
		this.lastMonthReading = lastMonthReading;
	}
	public float getCurrentMonthReading() {
		return currentMonthReading;
	}
	public void setCurrentMonthReading(float currentMonthReading) {
		this.currentMonthReading = currentMonthReading;
	}
	public float getUnitConsumed() {
		return unitConsumed;
	}
	public void setUnits(float unitConsumed) {
		this.unitConsumed = unitConsumed;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}
}