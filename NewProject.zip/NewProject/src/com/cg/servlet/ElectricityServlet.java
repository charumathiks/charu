package com.cg.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.bean.Electricity;

/**
 * Servlet implementation class Mobile
 */
@WebServlet("/ElectricityServlet")
public class ElectricityServlet extends HttpServlet {
	private static final long serialVersionUID =1L;
	
	public ElectricityServlet() {
		 super();
	}
	
	
	protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
		int consumerId = Integer.parseInt(request.getParameter("consumerId"));
		float lastMonthReading = Float.parseFloat(request.getParameter("lastMonthReading"));
		float currentMonthReading= Float.parseFloat(request.getParameter("currentmonthReading"));

		// Pass the mobile object into Request object to another servlet via
		// forward method

		Electricity ele = new Electricity();
		ele.setConsumerId(consumerId);
		ele.setLastMonthReading(lastMonthReading);
		ele.setCurrentMonthReading(currentMonthReading);
		
		request.setAttribute("electricity",ele);
		// we could also set couple of other parameters.

		

		// Obtain the request dispatcher object...via ServletContext object
		// Servlet Context can only take relative to the current context's root
		// As request is raised from POST method it will be forwarded to the
		// POST method of another servlet
//getServletContext().getRequestDispatcher("/DisplayElectricityInfo").forward(request, response);
	RequestDispatcher rd= getServletContext().getRequestDispatcher("/DisplayElectricityInfo");
	rd.forward(request, response);
	}


	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	       String Username=request.getParameter("Username");
	       String password=request.getParameter("password");
	       if(Username.equals("charu")&&password.equals("magacharu")) {
	    	   response.sendRedirect("Electricity.html");
	       }
	       else {
	    	response.sendRedirect("ElectricityLogin.html");  
	       }

}
}
