package om.capgemini.dao;

import java.sql.SQLException;

import com.capgemini.Exception.ElectricityBillException;
import com.capgemini.bean.ElectricityBillBean;

public interface IElectricityBillDao {
	public static final int FIXEDCHARGE = 100;
	public abstract int addDetails(ElectricityBillBean e) throws ElectricityBillException, SQLException;
	public abstract ElectricityBillBean getDetails(int billNum) throws ElectricityBillException, SQLException;
}
