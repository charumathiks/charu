package om.capgemini.dao;

import com.capgemini.DBUtil.DBConnection;
import com.capgemini.Exception.ElectricityBillException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bean.ElectricityBillBean;
import com.capgemini.service.IElectricityBill;


public class ElectricityBillDaoImplt implements IElectricityBillDao{

	@Override
	public int addDetails(ElectricityBillBean bean) throws ElectricityBillException, SQLException {
	
		int billNum = 0;
		int cusNum = bean.getCustNumber();
		float curReading = bean.getCurMonthReading();
		float unitConsumed = bean.getUnitsConsumed();
		float bill = bean.getBillamount();
		
		Connection con = DBConnection.getConnection();
		PreparedStatement st =  con.prepareStatement(IQueryMapper.INSERT_DETAILS);
		st.setInt(1,cusNum);
		st.setFloat(2, curReading);
		st.setFloat(3, unitConsumed);
		st.setFloat(4, bill);
		
		int rows = st.executeUpdate();
	
		if(rows > 0 ){
			st =  con.prepareStatement(IQueryMapper.GET_SEQUENCEVALUE);
			ResultSet rs = st.executeQuery();
			
			if(rs.next()){
				billNum = Integer.parseInt(rs.getString(1));
				bean.setBillNum(billNum);
			}
			
		}
	
		
		return billNum;
	}

	@Override
	public ElectricityBillBean getDetails(int billNum) throws ElectricityBillException, SQLException {
		ElectricityBillBean bean = new ElectricityBillBean();
		
		Connection con = DBConnection.getConnection();
		PreparedStatement st =  con.prepareStatement(IQueryMapper.SHOW_DETAILS);
		st.setInt(1, billNum);
		ResultSet rs = st.executeQuery();
	
		while(rs.next()){			
			bean.setCustNumber(rs.getInt("consumer_num"));
			bean.setCurMonthReading(rs.getFloat("cur_reading"));
			bean.setUnitsConsumed(rs.getFloat("unitconsumed"));
			bean.setBillamount(rs.getFloat("netamount"));
		}
		
		return bean;
	}

	
	

}
