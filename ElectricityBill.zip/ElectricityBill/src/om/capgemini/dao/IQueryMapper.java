package om.capgemini.dao;

public interface IQueryMapper {
	public static final String INSERT_DETAILS = "INSERT INTO BillDetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String SHOW_DETAILS = "SELECT consumer_num,cur_reading,unitconsumed,netamount FROM BillDetails WHERE bill_num = ?";
	public static final String GET_SEQUENCEVALUE = "SELECT seq_bill_num.currval FROM DUAL";
}
