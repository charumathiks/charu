package com.capgemini.bean;

public class ElectricityBillBean {
	private int custNumber;
	private float unitsConsumed;
	private float curMonthReading;
	private float billamount;
	private int billNum;
	
	public int getCustNumber() {
		return custNumber;
	}
	public void setCustNumber(int custNum) {
		this.custNumber = custNum;
	}
	
	public float getCurMonthReading() {
		return curMonthReading;
	}
	public void setCurMonthReading(float curMonthReading) {
		this.curMonthReading = curMonthReading;
	}
	public float getBillamount() {
		return billamount;
	}
	public void setBillamount(float billamount) {
		this.billamount = billamount;
	}
	public float getUnitsConsumed() {
		return unitsConsumed;
	}
	public void setUnitsConsumed(float unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}
	public int getBillNum() {
		return billNum;
	}
	public void setBillNum(int billNum) {
		this.billNum = billNum;
	}
	
	
	
}
