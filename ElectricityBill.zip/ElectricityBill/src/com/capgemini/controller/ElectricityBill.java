package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import om.capgemini.dao.IElectricityBillDao;

import org.jboss.security.auth.spi.Users.User;

import com.capgemini.Exception.ElectricityBillException;
import com.capgemini.bean.ElectricityBillBean;
import com.capgemini.service.ElectricityBillImplt;
import com.capgemini.service.IElectricityBill;
import com.sun.mail.iap.Response;

/**
 * Servlet implementation class ElectricityBill
 */
@WebServlet("/ElectricityBill")
public class ElectricityBill extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ElectricityBill() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*
		 * PrintWriter out=response.getWriter();
		 * out.println("success");
		 */
		PrintWriter out=response.getWriter();
		
		String operation = request.getParameter("sbutton"); 

		
		if(operation!=null && operation.equals("Login")){
			
			String name = request.getParameter("UserName");
			String pwd = request.getParameter("pwd");
			
			if(isValidUser(name, pwd))
				response.sendRedirect("ElectricityBill.html");
			else {
				response.sendRedirect("Login.html");
			}
			
		}
		else if(operation!=null && operation.equals("Calculate Bill")){
			
			int custNum = Integer.parseInt(request.getParameter("custNumber"));
			float lastMonthReading = Float.parseFloat(request.getParameter("LastMonthReading"));
			float currMonthReading = Float.parseFloat(request.getParameter("CurrentMonthReading"));
			
			float bill = (float)calculateBill(lastMonthReading, currMonthReading);
			
			ElectricityBillBean bean = new ElectricityBillBean();
			bean.setCustNumber(custNum);
			bean.setCurMonthReading(currMonthReading);
			bean.setUnitsConsumed(currMonthReading - lastMonthReading);
			bean.setBillamount(bill);
			IElectricityBill service = new ElectricityBillImplt();
			
			try {
				int billNum = service.addDetails(bean);
				out.println("Bill Id is " + billNum);
				ElectricityBillBean details = new ElectricityBillBean();
				details = service.getDetails(billNum);
				out.println("Customer Number: " +  bean.getCustNumber() + "</br>"+
						"Current Reading: " + bean.getCurMonthReading() + "</br>"+
						"Units consumed: " + bean.getUnitsConsumed() + "</br>"+
						"Bill Amount: " + bean.getBillamount() +"</br>"
				);
			} 
			catch (ElectricityBillException | SQLException e) {
				System.out.println(e.getMessage());
			}
			
		}
	}

	private boolean isValidUser(String name,String pwd){
		if(name.equals("Deepika") && pwd.equals("Kanna"))
			return true;
		else return false;
	}
	
	private double calculateBill(float lastMonthReading, float CurrMonthReading) {
		System.out.println("Reached Calculate Bill");
	
		double bill;
		float unitsConsumed = (CurrMonthReading - lastMonthReading);
		
		bill = (unitsConsumed * 1.15 ) + IElectricityBillDao.FIXEDCHARGE;
		
		return bill;
	}

}
