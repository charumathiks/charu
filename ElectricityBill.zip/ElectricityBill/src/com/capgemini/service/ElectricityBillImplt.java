package com.capgemini.service;

import java.sql.SQLException;

import om.capgemini.dao.ElectricityBillDaoImplt;
import om.capgemini.dao.IElectricityBillDao;

import com.capgemini.Exception.ElectricityBillException;
import com.capgemini.bean.ElectricityBillBean;

public class ElectricityBillImplt implements IElectricityBill {

	@Override
	public int addDetails(ElectricityBillBean e) throws ElectricityBillException, SQLException {
		IElectricityBillDao dao = new ElectricityBillDaoImplt();
		System.out.println("Reached Service");
		int billId = dao.addDetails(e);
		
		return billId;
		
	}

	@Override
	public ElectricityBillBean getDetails(int billNum) throws ElectricityBillException, SQLException {
		ElectricityBillBean bean = new ElectricityBillBean();
		IElectricityBillDao dao = new ElectricityBillDaoImplt();
		
		bean = dao.getDetails(billNum);
		
		return null;
	}

	

}
