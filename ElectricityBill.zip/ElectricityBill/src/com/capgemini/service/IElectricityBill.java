package com.capgemini.service;

import java.sql.SQLException;

import com.capgemini.Exception.ElectricityBillException;
import com.capgemini.bean.ElectricityBillBean;

public interface IElectricityBill {

	public abstract int addDetails(ElectricityBillBean e) throws ElectricityBillException, SQLException;
	public abstract ElectricityBillBean getDetails(int billNum) throws ElectricityBillException, SQLException;
	
}
