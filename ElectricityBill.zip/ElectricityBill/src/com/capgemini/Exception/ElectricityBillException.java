package com.capgemini.Exception;

/*
 * UserDefined Exception-ElectricityBillException
 */
public class ElectricityBillException extends Exception{
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ElectricityBillException(String message) {
		super(message);
	}
	
}
