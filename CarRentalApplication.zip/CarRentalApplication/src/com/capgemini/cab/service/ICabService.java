package com.capgemini.cab.service;

import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

public interface ICabService {
int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException;
CabRequest getRequestDetails(int requestId) throws CabRequestException;
boolean isValidName(String custName);
boolean isValidNumber(String phoneno);
boolean isValidAddress(String address);
String getCarNumber(String pincode);
}
