package com.igate.interservletcomm.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.igate.interservletcomm.bean.Mobile;
import com.igate.interservletcomm.bean.Product;

/**
 * Servlet implementation class Mobile
 */
@WebServlet("/MobileServlet")
public class MobileServlet extends HttpServlet {
	private static final long serialVersionUID =1L;
	
	public MobileServlet() {
		 super();
	}
	
	
	protected void doGet(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException {
		String mobileName = request.getParameter("mobileName");
		String mobileBrand = request.getParameter("mobileBrand");
		int price = Integer.parseInt(request.getParameter("price"));

		// Pass the mobile object into Request object to another servlet via
		// forward method

		Mobile mob = new Mobile();
		mob.setmobileName(mobileName);
		mob.setmobileBrand(mobileBrand);
		mob.setprice(price);
		
		request.setAttribute("mobile",mob);
		// we could also set couple of other parameters.

		request.setAttribute("shopName", "chennaiMobiles");
		request.setAttribute("mail", "feedback@chennaimobiles.com");

		// Obtain the request dispatcher object...via ServletContext object
		// Servlet Context can only take relative to the current context's root
		// As request is raised from POST method it will be forwarded to the
		// POST method of another servlet
//getServletContext().getRequestDispatcher("/DisplayMobileInfo").forward(request, response);
	RequestDispatcher rd= getServletContext().getRequestDispatcher("/DisplayMobileInfo");
	rd.forward(request, response);
	}

	
	

}
