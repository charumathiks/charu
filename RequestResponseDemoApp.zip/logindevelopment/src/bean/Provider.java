package bean;

public interface Provider {
String DRIVER="oracle.jdbc.driver.OracleDriver";
String CONNECTION_URL="jdbc:oracle:thin:@10.219.34.3:1521/orcl";
String USERNAME="training";
String PASSWORD="training";

}
