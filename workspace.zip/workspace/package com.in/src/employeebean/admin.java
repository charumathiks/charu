package employeebean;

 class empdetails {
 private String role;
 private int Salary;
 private String name;
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public int getSalary() {
	return Salary;
}
public void setSalary(int salary) {
	Salary = salary;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public empdetails(String role, int salary, String name) {
	this.role = role;
	Salary = salary;
	this.name = name;
}
public class Admin
{
	public static void main(String args[]) 
	{
		empdetails details= new empdetails("Analyst",18000,"sundar");
	     System.out.println(details.getRole());
	     
	     System.out.println(details.getSalary());
	     System.out.println();
	     
	}
}
}
