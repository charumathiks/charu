package com.im;

public class Obj {

	public static void main(String[] args) {
		Object ob;
		String s=null;
		ob=s;
		String s1="hello";
		ob=s1;
		System.out.println(ob);
		

}
}