package com.comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableEg {

	public static void main(String[] args) {
		
		 	List<Movie> list = new ArrayList<>();
	        list.add(new Movie(8.3, "Sachin", 2008));
	        list.add(new Movie(8.7, "Evade Subramaniyam", 2010));
	        list.add(new Movie(8.8, "Nani", 2012));
	        list.add(new Movie(8.4, "veppam", 2014));
	 
	        Collections.sort(list);
	 
	        System.out.println("Movies after sorting : ");
	        for (Movie movie: list)
	        {
	            System.out.println(movie.getName() + " " +
	                               movie.getRating() + " " +
	                               movie.getYear());
	        }
	}

}
