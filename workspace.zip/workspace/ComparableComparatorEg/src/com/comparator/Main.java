package com.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.comparable.Movie;

/**
 * @author gowthc
 *
 */
public class Main {

	public static void main(String[] args) {
		 	List<Movie> list = new ArrayList<Movie>();
	        list.add(new Movie(8.3, "Sachin", 2008));
	        list.add(new Movie(8.7, "Evade Subramaniyam", 2010));
	        list.add(new Movie(8.8, "Nani", 2012));
	        list.add(new Movie(8.4, "Veppam", 2014));
	 
	        // Sort by rating : (1) Create an object of ratingCompare
	        //                  (2) Call Collections.sort
	        //                  (3) Print Sorted list
	        System.out.println("Sorted by rating");
	        RatingCompare ratingCompare = new RatingCompare();
	        Collections.sort(list, ratingCompare);
	        for (Movie movie: list)
	            System.out.println(movie.getRating() + " " +
	                               movie.getName() + " " +
	                               movie.getYear());
	 
	 
	        // Call overloaded sort method with RatingCompare
	        // (Same three steps as above)
	        System.out.println("\nSorted by name");
	        NameCompare nameCompare = new NameCompare();
	        Collections.sort(list, nameCompare);
	        for (Movie movie: list)
	            System.out.println(movie.getName() + " " +
	                               movie.getRating() + " " +
	                               movie.getYear());
	 
	        // Uses Comparable to sort by year
	        System.out.println("\nSorted by year");
	        Collections.sort(list);
	        for (Movie movie: list)
	            System.out.println(movie.getYear() + " " +
	                               movie.getRating() + " " +
	                               movie.getName()+" ");
	}

}
