package com.inn.Downward;

public class Regular extends Student {
public void payBusFee()
{
	System.out.println("busFee");
}
}
