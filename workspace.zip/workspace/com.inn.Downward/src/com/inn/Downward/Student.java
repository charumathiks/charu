package com.inn.Downward;

public class Student {
public void study()
{
	System.out.println("study");
}
}
