package com.inn.Downward;

public class Testcases {

	public static void main(String[] args) {
		Regular r=new Regular();
		r.study();
		r.payBusFee();
	}

}
