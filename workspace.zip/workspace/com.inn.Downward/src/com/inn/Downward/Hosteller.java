package com.inn.Downward;

public class Hosteller extends Student {
public void study()
{
	System.out.println("study");
}
public void payHostelFee()
{
	System.out.println("hostelFee");
}
}
