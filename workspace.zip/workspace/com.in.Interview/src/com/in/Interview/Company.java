package com.in.Interview;

public class Company {
 public String BE() {
	return null;
}
 public String Bsc() {
	return null;
}
public String BTech() {
	return null;
}
 
 
}
