package com.cg;

public class VarArgEx {

	public static void main(String[] args) {
		VarArgEx ob= new VarArgEx();
		  ob.display();
		//ob.display("null);"
		ob.display("Hello");
		ob.display("welcome","how");
	  
	}
	
	void display(String...data){
	System.out.println("in display" +data);
	for(String g:data){
	System.out.println(g);
	}
	}
}

