package com.author.recharge.bean;

public class RechargeBean {
	private String userName;
	private String userMobileNum;
	private String userEmailId;
	private String planName;
	private String status;
	private String rechId;
	public String getRechId() {
		
		return this.rechId;
	}
	public void setRechId(String rechId) {
		this.rechId = rechId;
	}
	private int amount;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserMobileNum() {
		return userMobileNum;
	}
	public void setUserMobileNum(String userMobileNum) {
		this.userMobileNum = userMobileNum;
	}
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String toString()
	{
		return "Your last recharge details\nRechargeId:"+this.rechId+"\nUserName:"+this.userName+"\nMobile number:"+this.userMobileNum+"\nStatus:"+this.status+"\nPlan name:"+this.planName+"\nAmount:"+this.amount;
	}
}
