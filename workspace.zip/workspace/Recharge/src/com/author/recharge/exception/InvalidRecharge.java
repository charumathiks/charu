package com.author.recharge.exception;

public class InvalidRecharge extends Exception{
private String msg;
public InvalidRecharge()
{
	
}
public InvalidRecharge(String msg)
{
this.msg=msg;
}
public String toString()
{
	return this.msg;
}
}
