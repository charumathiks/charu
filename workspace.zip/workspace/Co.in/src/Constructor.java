package Co.in;

public class Constructor {
 public int empNo;
 public String empName;
 public String Designation;
public Constructor(int empNo, String empName, String designation) {
		this.empNo = empNo;
	this.empName = empName;
	Designation = designation;
}
}
