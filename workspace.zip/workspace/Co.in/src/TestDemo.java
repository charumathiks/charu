
public class TestDemo {

	public static void main(String[] args) {
		Constructor cons=new Constructor();
		System.out.println(cons.Designation);

	}

}
