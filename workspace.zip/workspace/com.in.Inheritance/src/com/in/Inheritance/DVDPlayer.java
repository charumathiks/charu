package com.in.Inheritance;

public class DVDPlayer extends ElectronicDevices{
public void record()
{
	System.out.println("recording");
}
public void repeat()
{
	System.out.println("repeat");
}
}
