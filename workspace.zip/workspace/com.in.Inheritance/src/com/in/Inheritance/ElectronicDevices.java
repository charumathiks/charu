package com.in.Inheritance;

public class ElectronicDevices {
public void audio()
{
	System.out.println("audio");
}
public void powerSupply()
{
	System.out.println("powerSupply");
}
public void on()
{
	System.out.println("on");
}
public void off()
{
	System.out.println("off");
}
}
