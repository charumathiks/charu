package com.in.Inheritance;

public class Radio extends ElectronicDevices{
public void satelliteRadio()
{
	System.out.println("wireless");
}
public void InternetService()
{
	System.out.println("Network");
}
}
