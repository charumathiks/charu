package com.in.Inheritance;

public class ClassDemo {

	public static void main(String[] args) {
		Radio ra=new Radio();
		ra.audio();
		ra.satelliteRadio();
		ra.InternetService();
	}

}
