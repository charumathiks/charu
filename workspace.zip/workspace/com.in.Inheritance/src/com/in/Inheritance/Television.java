package com.in.Inheritance;

public class Television extends ElectronicDevices {
public void Channels()
{
	System.out.println("MoreChannels");
}
public void WebBrowsing()
{
	System.out.println("internet");
}
public void games()
{
	System.out.println("gaming");
}

}
