package cg.imm;
import java.util.ArrayList;
import java.util.List;

public class ListEg1 {

	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		List<Comparable> l =new ArrayList<Comparable>();
		l.add("hello");
		l.add("hi");
		l.add("how r u!!!");
		l.add(89);
		l.add(90);
		l.add("*");
		l.add(null);
		l.add(45);
		l.add(45);
		System.out.println("data list is:" +l);
        l.remove("hello");
        System.out.println("");
	}

}
