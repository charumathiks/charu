package com.cg.Inheritance;

public class Employee {
public void empId()
{
	System.out.println("Id");
}
public void empName()
{
	System.out.println("Name");
}
public void empDesignation()
{
	System.out.println("Designation");
}
public void companyName()
{
	System.out.println("companyName");
}
}
