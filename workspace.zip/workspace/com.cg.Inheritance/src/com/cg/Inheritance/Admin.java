package com.cg.Inheritance;

public class Admin{
	
}
