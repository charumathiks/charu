package appli;

public class apple {
	private int studId;
	public String studName;
	private String studpass;
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudpass() {
		return studpass;
	}
	public void setStudpass(String studpass) {
		this.studpass = studpass;
	}
	
      
}
