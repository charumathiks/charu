package appli;

public class cha {

	public static void main(String[] args) {
	/*for(int i=1;i<5;i++)
	{
		System.out.println("The value of i is:" +i); 
	}*/
		/*boolean cond = 5!=0;
		System.out.println(cond);*/
		/*int myint=20;
		if(myint<0)
		{
			System.out.println("Yes, it's true!");
		}*/
		/*int myint=34;
		if (myint<50)
		{
			System.out.println("Yes,it's true!");
		}
		else {
			System.out.println("No,it's false");
		}*/
		/*int myint=60;
		if (myint<15)
		{
			System.out.println("Yes,it's true!");
		}
		else if(myint>20)
		{
			System.out.println("No,it's false");
		}*/
		/*int myint=18;
		if (myint<15)
		{
			System.out.println("Yes,it's true!");
		}
		else if(myint>20)
		{
			System.out.println("No,it's false");
		}
		else {
			System.out.println("none of the above");
		}*/
		/*int loop=0;
		while(loop<7){
			System.out.println("looping" +loop);
            loop++;
		}*/
		/*int loop=0;
		while(loop<7){
			System.out.println("looping: " +loop);
			if(loop==7)
			{
				break;
			}
			System.out.println("Running");
           
		}*/
		int loop=0;
		while(loop<7){
			System.out.println("looping: " +loop);
			if(loop==7)
			{
				break;
			}
			loop++;
			System.out.println("Running");
           
		}

	}

}
