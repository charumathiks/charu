package inheri;

public class TestCase {

	public static void main(String[] args) {
Human1 h=new Human1();
h.think();
h.talk();
h.walk();

	}

}
