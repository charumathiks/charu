package inheri;

public class Human1 extends Primate {
public void think()
{
	System.out.println("think");
}
public void talk()
{
	System.out.println("talk");
}
}
