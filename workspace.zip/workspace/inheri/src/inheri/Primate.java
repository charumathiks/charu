package inheri;

public class Primate {

	public void eat()
     {
	   System.out.println("eat");
      }
	public void sleep()
	{
		System.out.println("sleep");
	}
	public void jump()
	{
		System.out.println("jump");
	}
	public void walk()
	{
		System.out.println("walk");
}

	}

