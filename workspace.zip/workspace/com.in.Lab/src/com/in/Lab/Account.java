package com.in.Lab;

public class Account {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
