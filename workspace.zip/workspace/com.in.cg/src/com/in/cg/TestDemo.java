package com.in.cg;

public class TestDemo {

	public static void main(String[] args, char[] EmpId) {
		
		System.out.println(EmpId);
		System.out.println("");

	}

}
