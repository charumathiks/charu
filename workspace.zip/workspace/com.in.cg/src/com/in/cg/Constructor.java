package com.in.cg;

public class Constructor {
public int EmpId;
public String designation;
public String EmpName;
public Constructor(int empId, String designation, String empName) {
	super();
	EmpId = empId;
	this.designation = designation;
	EmpName = empName;
}

}
