package com.cg;

public class whil {

	public static void main(String[] args) {
		/*int var=0;
		for(; var < 10;)
		{
			System.out.println(var);
			var++;
		}*/
		/*int num;
		for(num=0;num<10;num++)
		{
			System.out.println("my number is:" +num);
		}*/
		/*int value=0;
		while(value<10)
		{
			System.out.println("hello" +value);
			value = value+1;
		}*/
	/*int var=9;
	while (var<10)
	{
		System.out.println("hello");
		var++;
	}*/
	int var = 1;
	for (; var < 10; )
	{
		System.out.println(var);
		var++;
	

}
	}
	}
