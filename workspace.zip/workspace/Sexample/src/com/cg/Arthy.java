package com.cg;

public class Arthy {

	public static void main(String[] args) {
		/*int number=67;
		if(number%2==0)
			System.out.println("the number is even");
		else
			System.out.println("the number is odd");
		}*/
          /*int var=0;
          do
          {
        	  System.out.println("hello");
        	  var++;
          }
          while(var<5);*/
		String text="hi";
		String blank=" ";
		String name="Charu!!!"; 
		String greeting=text+blank+name;
		System.out.println(greeting);
}
		
}       