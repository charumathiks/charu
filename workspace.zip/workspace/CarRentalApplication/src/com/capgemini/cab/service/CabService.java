
package com.capgemini.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;


public class CabService implements ICabService{
	
	@Override
	public int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException {
		ICabRequestDAO cabRequestDao=new CabRequestDAO();
		return cabRequestDao.addCabRequestDetails(cabRequest);
	}
	
	@Override
	public CabRequest getRequestDetails(int requestId) throws CabRequestException {
		ICabRequestDAO cabRequestDao=new CabRequestDAO();
		return cabRequestDao.getRequestDetails(requestId);
	}
	
	@Override
	public boolean isValidName(String custName) {
		Pattern p=Pattern.compile("[A-Z][a-zA-Z]*{3,}");
		Matcher m=p.matcher(custName);
		if(m.matches())
			return true;
		else
		{
			System.out.println("Name is Invalid. It should start with Capital letter and should be minimum 3 characters");
			return false;
		}
	}
	
	@Override
	public boolean isValidNumber(String phoneNo) {
		Pattern p=Pattern.compile("[6-9][0-9]{9}");
		Matcher m=p.matcher(phoneNo);
		if(m.matches())
			return true;
		else
		{
			System.out.println("Invalid Phone Number");
			return false;
		}
	}

	@Override
	public boolean isValidAddress(String address) {
		Pattern p=Pattern.compile("[A-Z].*{3,}");
		Matcher m=p.matcher(address);
		if(m.matches())
			return true;
		else
		{
			System.out.println("Address is Invalid. It should start with Capital letter and should be minimum 3 characters");
			return false;
		}
	}
	

	@Override
	public String getCarNumber(String pincode) {
		if(pincode.equals("400096"))
		{
			return "MH VS 2345";
		}
		else if(pincode.equals("411026"))
		{
			return "MH VH 34567";
		}
		else if(pincode.equals("411013"))
		{
			return "MH AN 97886";
		}
		else if(pincode.equals("560066"))
		{
			return "MH AS 875";
		}
		else if(pincode.equals("382009"))
		{
			return "MH KN 9856";
		}
		else if(pincode.equals("400708"))
		{
			return "MH TF 8956";
		}
		else 
			return null;
	}
}
