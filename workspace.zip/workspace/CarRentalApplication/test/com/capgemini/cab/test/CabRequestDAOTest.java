package com.capgemini.cab.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.cab.dao.CabRequestDAO;
import com.capgemini.cab.dao.ICabRequestDAO;
import com.capgemini.cabs.bean.CabRequest;

public class CabRequestDAOTest {

	static ICabRequestDAO cabRequestDao=null;
	static CabRequest cabRequest=null;
	@BeforeClass
	public static void Initialize()
	{
		cabRequestDao=new CabRequestDAO();
		cabRequest=new CabRequest();
	}
	@Test
	public void test() {
		
	}

}
