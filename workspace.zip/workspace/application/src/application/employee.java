package application;

public class employee {
	
int eId;
public String empName;
public String designation;
public String password;
public int geteId() {
	return eId;
}
public void seteId(int eId) {
	this.eId = eId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}
