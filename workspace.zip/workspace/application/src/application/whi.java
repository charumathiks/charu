package application;

public class whi {

	public static void main(String[] args) {
/*double mydouble=908.09;
		System.out.println("my number is:" +mydouble +".");*/
		//int var=0;
		/*do { System.out.println("hello"); var++; } while(var<5);*/
		/*while(var<10); { System.out.println("hello"); var++; }*/

		int age=45;
		System.out.println(age>18);
		if(age>18)
		{
			System.out.println("welcome");
			System.out.println("u r eligible");
			}
		else
		{
			System.out.println("not eligible");
			System.out.println("as ur age is less than 18");
		}
		
		
	
	
	}
	

}
