package application;

public class tuti {

	public static void main(String[] args) {
	  int mynum = 89;
	  short myshort = 567;
	  long mylong=456789;
	  float myfloat=67.89f;
	  boolean myboolean= false;
	  System.out.println(mynum);
	  System.out.println(myshort);
	  System.out.println(mylong);
	  System.out.println(myfloat);
      System.out.println(myboolean);
	}

}
