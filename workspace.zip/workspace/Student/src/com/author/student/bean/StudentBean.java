package com.author.student.bean;

public class StudentBean {
private String studName;
private String department;
private int rollNo;
private int marks;
private String address;
public String getStudName() {
	return studName;
}
public void setStudName(String studName) {
	this.studName = studName;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public int getRollNo() {
	return rollNo;
}
public void setRollNo(int rollNo) {
	this.rollNo = rollNo;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}

public String toString()
{
	StringBuilder sb=new StringBuilder();
	sb.append("displaying student details\n");
	sb.append("studName" +studName +"\n");
	sb.append("department" +department +"\n");
	sb.append("rollNo" +rollNo +"\n");
	sb.append("marks" +marks +"\n");
	sb.append("address" +marks +"\n");
	return sb.toString();
}

}
