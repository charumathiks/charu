package com.author.student.service;

public class StudentServiceImpl {

}
