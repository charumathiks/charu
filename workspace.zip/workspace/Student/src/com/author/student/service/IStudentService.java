package com.author.student.service;

public class IStudentService {

}
