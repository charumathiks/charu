package com.author.student.pi;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
