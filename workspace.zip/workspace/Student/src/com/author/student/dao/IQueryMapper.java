package com.author.student.dao;

public class IQueryMapper {

}
