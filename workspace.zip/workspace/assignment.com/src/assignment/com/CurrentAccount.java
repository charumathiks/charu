package assignment.com;

public class CurrentAccount extends Account {
	private final int overDraftLimit=5000;
	@Override
	public void withdraw(double balance)
	{
		if((this.balance+balance)>overDraftLimit)
			System.out.println(true);
		else
			System.out.println(false);
	}
}
