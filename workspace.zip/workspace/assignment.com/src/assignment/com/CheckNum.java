package assignment.com;

import java.util.Scanner;

public class CheckNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scan=new Scanner(System.in);
int number=scan.nextInt();
if(number <0)
{
	System.out.println(number+ ":is a negative number");
	
}
else if(number>0)
{
	System.out.println(number+ ":is a positive number");
}
else
	System.out.println("zero is entered");
	}

}
