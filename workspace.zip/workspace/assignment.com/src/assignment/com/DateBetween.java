package assignment.com;
import java.util.*;
import static java.lang.Math.*;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
public class DateBetween {
public static void main(String[] args) {

	Scanner s=new Scanner(System.in);
	System.out.println("\nEnter date1 in following format(DD/Mon/YYYY)");	
	String str=s.next();
		String date1[]=str.split("/");
		System.out.println("\nEnter date2 in following format(DD/Mon/YYYY)");	
		String str2=s.next();	
		String date2[]=str2.split("/");
	
		LocalDate bday = LocalDate.of(Integer.parseInt(date1[2]),Month.valueOf(date1[1]),Integer.parseInt(date1[0]));
	     LocalDate today = LocalDate.of(Integer.parseInt(date2[2]),Month.valueOf(date2[1]),Integer.parseInt(date2[0]));
	        
	     Period age = Period.between(today, bday);
	    
	     int days=abs(age.getDays());
	     int years = abs(age.getYears());
	     int months = abs(age.getMonths());

	        System.out.println("No of days:"+days+"\nNo of months "+months+"\nNo of years "+years);
	}	
	}


