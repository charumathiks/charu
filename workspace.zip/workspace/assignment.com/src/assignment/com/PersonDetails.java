package assignment.com;
import java.util.Scanner;
public class PersonDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          String fname, lname;
          char gender;
          int age;
          float weight;
          Scanner sc =new Scanner(System.in);
          System.out.println("enter first name:");
          fname=sc.next();
          System.out.println("enter last name:");
          lname=sc.next();
          System.out.println("gender");
          gender=sc.next().charAt(0);
          System.out.println("age");
          age=sc.nextInt();
          System.out.println("weight");
          weight=sc.nextFloat();
          System.out.println("Person Details:");
          System.out.println("-------------------");
          System.out.println("first name:"+fname);
          System.out.println("last name:"+lname);
          System.out.println("gender:"+gender);
          System.out.println("age:"+age);
          System.out.println("weight:"+weight);
	}

}
