package assignment.com;

public class Details {

}
