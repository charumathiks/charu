package assignment.com;

public class SavingAccount extends Account {
	private final int minmumBalance=500;
	@Override
	public void withdraw(double balance)
	{
		if((this.balance-balance)<=this.minmumBalance)
			System.out.println("Cannot be withdrawn minimum balance is Rs.500.");
		else
		this.balance-=balance;
	}
}
