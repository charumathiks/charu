package com.igate.dth.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.igate.dth.dto.Subscriber_Account_Details;
import com.igate.dth.exception.DataSkyException;

public interface DataSkyDao {
	public ArrayList<Subscriber_Account_Details> showMobileNos(long operations) throws SQLException, NamingException;
	public int updateAmount(int opera2) throws DataSkyException, SQLException, NamingException;
}
