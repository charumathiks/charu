package com.igate.dth.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.time.LocalDate;

import javax.naming.NamingException;

import com.igate.dth.dto.Subscriber_Account_Details;
import com.igate.dth.exception.DataSkyException;
import com.igate.dth.util.DBUtil;

/*
 * Database class - with all the database queries
 */
public class DataSkyDaoImpl implements DataSkyDao {

	Connection connection = null;
	Statement statement = null;
	ResultSet rsSet = null;
	PreparedStatement preparedStatement = null;	
	ArrayList<Subscriber_Account_Details> list;
	Subscriber_Account_Details sad;
	static long mobile_Number;
	String id = null;
	int package_amount = 0;
	int account_bal = 0;
	int recommendedRC = 0;
	
	@Override
	public ArrayList<Subscriber_Account_Details> showMobileNos(long mobileNo)	throws SQLException, NamingException 
	{		
		try 
		{
			connection = DBUtil.obtainConnection();
		} catch (DataSkyException e1) {			
			System.err.println(e1.getMessage());
		}
		list = new ArrayList<Subscriber_Account_Details>();
		sad = new Subscriber_Account_Details();
		mobile_Number = mobileNo;
				
		try 
		{
			String packamount = "SELECT d.package_amount, s.package_id, s.account_balance FROM datasky_packages d,subscriber_account_details s WHERE d.package_id=s.package_id AND mobile_number=?";
			PreparedStatement stamount = connection.prepareStatement(packamount);
			stamount.setLong(1, mobileNo);
			rsSet = stamount.executeQuery();
			while (rsSet.next()) {
				package_amount = rsSet.getInt("package_amount");
				id = rsSet.getString("package_id");
				account_bal = rsSet.getInt("account_balance");
			}
			recommendedRC = package_amount - account_bal;

			PreparedStatement st = connection.prepareStatement("SELECT * FROM subscriber_account_details WHERE mobile_number = ?");
			st.setLong(1, mobileNo);			
			rsSet = st.executeQuery();			
			while (rsSet.next()) 
			{
				if (rsSet.getLong("mobile_number") == mobileNo) 
				{					
					sad.setSubscriber_id(rsSet.getInt("subscriber_id"));
					sad.setMobile_number(rsSet.getLong("mobile_number"));
					sad.setPackage_id(rsSet.getString("package_id"));
					sad.setRechargeDate(rsSet.getDate("rechargedate"));
					sad.setAccount_balance(rsSet.getInt("account_balance"));
					sad.setRecommended_RC(recommendedRC);
					list.add(sad);					
				} else {					
					list.add(null);					
				}
			}	
		}
		catch(SQLException e) {
			try {
				throw new DataSkyException("Error while fetching values::"
						+ e.getMessage());
			} catch (DataSkyException e1) {
				System.err.println("Exception:"+e1.getMessage());
			}
		}
		return list;
	}

	@Override
	public int updateAmount(int upamt) throws DataSkyException, SQLException, NamingException 
	{
		connection = DBUtil.obtainConnection();
		int rs=0;
		Date date = null;		
		try 
		{
			String sql = "SELECT rechargedate FROM subscriber_account_details";
			Statement se= connection.createStatement();
			rsSet=se.executeQuery(sql);
			while(rsSet.next())
			{
				date=rsSet.getDate("rechargeDate");
			}
			PreparedStatement st = connection.prepareStatement("UPDATE subscriber_account_details SET account_balance=account_balance+? WHERE mobile_number = ?");
			st.setInt(1, upamt);
			st.setLong(2, mobile_Number);			
			rs=st.executeUpdate();			
		}
		catch(Exception e)
			{
				System.err.println("SOME ERROR IN UPDATION "+e.getMessage());
			}
		return rs;
	}	
}                  