package com.igate.dth.exception;
/*
 * User defined exception class
 */
public class DataSkyException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public DataSkyException(String message) {
		super(message);
	}
}
