package com.igate.dth.dto;

import java.sql.Date;
import java.time.LocalDate;

public class Subscriber_Account_Details 
{
	private int subscriber_id;
	private long mobile_number;
	private String package_id;
	private int account_balance;
	private Date rechargeDate ;
	private int recommended_RC;
	
	public int getRecommended_RC() {
		return recommended_RC;
	}
	public void setRecommended_RC(int recommended_RC) {
		this.recommended_RC = recommended_RC;
	}
	public int getSubscriber_id() {
		return subscriber_id;
	}
	public void setSubscriber_id(int subscriber_id) {
		this.subscriber_id = subscriber_id;
	}
	public long getMobile_number() {
		return mobile_number;
	}
	public void setMobile_number(long mobile_number) {
		this.mobile_number = mobile_number;
	}
	public String getPackage_id() {
		return package_id;
	}
	public void setPackage_id(String package_id) {
		this.package_id = package_id;
	}
	public int getAccount_balance() {
		return account_balance;
	}
	public void setAccount_balance(int account_balance) {
		this.account_balance = account_balance;
	}
	public Date getRechargeDate() {
		return rechargeDate;
	}
	public void setRechargeDate(Date date) {
		this.rechargeDate = date;
	}
}
