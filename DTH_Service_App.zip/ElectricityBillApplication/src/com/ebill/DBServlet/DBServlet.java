package com.ebill.DBServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.ebill.bean.BillBean;

/**
 * Servlet implementation class DBServlet
 */
@WebServlet("/DBServlet")
public class DBServlet extends HttpServlet {
	@Resource(lookup="java:/OracleDS")
	DataSource ds;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DBServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		BillBean bean = (BillBean) request.getAttribute("insertConsDetails");
		try {
			Connection connection = ds.getConnection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			preparedStatement=connection.prepareStatement("INSERT INTO billdetails VALUES(seq_bill_num.NEXTVAL,?,?,?,?,SYSDATE)");
			preparedStatement.setDouble(1, bean.getConsNum());
			preparedStatement.setDouble(2, bean.getCurrReading());
			preparedStatement.setDouble(3, bean.getUnitConsumed());
			preparedStatement.setDouble(4, bean.getNetAmount());
			
			resultSet=preparedStatement.executeQuery();
			//connection.commit();		
			if(resultSet.next()){
				out.print("<h2>Welcome </h2>"+bean.getConsName());
				out.print("<br/><b>Electricity Bill for Consumer Number - "+bean.getConsNum()+" is </b>");
				out.print("<br/>Unit Consumed :: "+bean.getUnitConsumed());
				out.print("<br/>Net Amount :: Rs."+bean.getNetAmount());
				
			}
			else
			{
				out.print("<br/><center><h2>Failed to store the details</h2></center>");
			}
		}		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
