package com.cn.ch4;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;








import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class Database
 */
@WebServlet("/Database")
public class NewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Resource(lookup="java:/OracleDS")
	DataSource ds;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		InitialContext ic;
		try {
		    Connection con= ds.getConnection();
			Statement st= con.createStatement();
			ResultSet rs=st.executeQuery("select * from employees");
			PrintWriter out=response.getWriter();
			while(rs.next())
			{
				out.println(rs.getInt("EMPLOYEE_CODE"));
				out.println(rs.getString("EMPLOYEE_NAME"));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
}
	
	
}

	
	


