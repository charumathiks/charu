package com.igate.interservletcomm.bean;

public class Mobile {
	private String mobileName;
	private String mobileBrand;
	private int price;
	public String getmobileName() {
		return mobileName;
	}
	public void setmobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public String getmobileBrand() {
		return mobileBrand;
	}
	public void setmobileBrand(String mobileBrand) {
		this.mobileBrand = mobileBrand;
	}
	public int getprice() {
		return price;
	}
	public void setprice(int price) {
		this.price = price;
	}
	
	
}
